# Project 1 – Prokudin-Gorskii Colorization

## Requirements
- Python 3.9+ (Anaconda recommended)
- Dependencies: `numpy`, `scipy`, `pillow`


Install dependencies with:
```bash
pip install numpy scipy pillow
```
# To run the code
```bash
cd code
python main.py
```

The pictures need to be in a subfolder called images. In this folder, there need to be a subfolder for every class of pictures - small, large and large-extra - respectively.

The complete directory should look something like this:

![my repo structure](image.png)
